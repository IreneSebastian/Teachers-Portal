import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { HelloworldComponent } from './helloworld/helloworld.component';
import { DemoComponent } from './demo/demo.component';
import { AppComponent } from './app.component';

const routes: Routes = [{path:'home',component:HelloworldComponent}
,{path:'features',component:ProfileComponent},{path:'apply',component:DemoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
