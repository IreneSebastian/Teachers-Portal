import { Component, OnInit } from '@angular/core';
import{student} from '../students';
import { from } from 'rxjs';
import{NgForm} from '@angular/forms';
import{ MyserviceService } from '../myservice.service';


@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
student = new student();
isRegistered=false;
  constructor(private applyservice:MyserviceService) { }

  ngOnInit() {
  }
  registration(f:NgForm){
  this.applyservice.store(this.student).subscribe(data=>{
    this.isRegistered=true;
    console.log("registered sucesfully");
    f.reset();
  },
  (err)=>{
    this.isRegistered=false;
  });
  }

}
