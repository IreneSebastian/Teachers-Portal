export class student{
    id?:Number;
    name:string;
    uname:string;
    password:string;
    constructor(){
        this.name='';
        this.uname='';
    }
}