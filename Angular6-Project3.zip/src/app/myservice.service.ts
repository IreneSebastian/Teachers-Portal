import { Injectable } from '@angular/core';
import {HttpClient,HttpErrorResponse} from '@angular/common/http';
import { from, Observable, throwError } from 'rxjs';
import {student} from './students';
import {map,catchError} from 'rxjs/Operators';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
student:student[];
  constructor(private http:HttpClient) {
    
   }
   store(student:student):Observable<student[]>{
     return this.http.post(`http://localhost/reg.php`,{ data:student}).pipe(map((res)=>{
       this.student=(res['data']);
       return this.student;
    }),
    );
   }
   private handleError(error:HttpErrorResponse){
     return console.log(error);
     return throwError('error occured');
   }
   
}
