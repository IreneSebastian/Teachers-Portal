﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace Registration.Models
{
    public class Register
    {
        [Required(ErrorMessage="*required")]
        [Display(Name="Name")]
        public string sname{ get; set; }

        [Required(ErrorMessage = "*required")]
        [Display(Name = "Address")]
        [DataType(DataType.MultilineText)]
        public string saddress{ get; set; }

        [Required(ErrorMessage = "*required")]
        [Display(Name = "Gender")]
        
        public string sgender{ get; set; }

        [Required(ErrorMessage = "*required")]
        [Display(Name = "Course")]
        
        public string scourse{ get; set; }

        [Required(ErrorMessage = "*required")]
        [Display(Name = "Image")]
        public string simage{ get; set; }


        [Required(ErrorMessage = "*required")]
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress)]
        public string semail{ get; set; }

        [Required(ErrorMessage = "*required")]
        [Display(Name = "Username")]
        [DataType(DataType.Text)]
        public string suser{ get; set; }

        [Required(ErrorMessage = "*required")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string spassword{ get; set; }

        [Required(ErrorMessage = "*required")]
        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        public string sconfirm{ get; set; }
    }
    public enum Course
    {
        MCA,
        BCA,
        MCOM,
        MBA
    }
}