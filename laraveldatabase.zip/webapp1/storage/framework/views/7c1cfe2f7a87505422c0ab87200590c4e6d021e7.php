<?php $__env->startSection('content'); ?>
<h1>Index Page</h1>
<h2>hi this is index page</h2>
<h3><?php echo e($name); ?></h3>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>