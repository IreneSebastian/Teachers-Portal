
@extends('layouts.app1')
@section('content')
<h1>Service Page</h1>
<h2>This is service page</h2>
@endsection
