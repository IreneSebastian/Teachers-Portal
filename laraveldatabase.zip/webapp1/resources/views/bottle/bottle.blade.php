<form method="post" action="{{route('bottle.store')}}">
@csrf
Name: <input type="text" name="title"/><br/>
Company:<input type="text" name="company"/><br/>
Brand:<input type="text" name="brand" /><br/>
<button type="submit" name="submit">Add</button>
</form>