<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SharesController extends Controller
{
    public function about()
	{
	$number="24";
	return view('Shares.about')->with('value',$number);
	}
	 public function index()
	{
	$title="irene";
	return view('Shares.index')->with('name',$title);
	}
	 public function services()
	{
	return view('Shares.services');
	}
}
