<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bottle extends Model
{
   public $fillable=[
	'title',
	'company',
	'brand'
	];
}
