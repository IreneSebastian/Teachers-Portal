import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
public studentdetails:any=[{rollno:"1",name:"irene",batch:"MCA",department:"Computer Applications"},
                          {rollno:"2",name:"gopika",batch:"MCA",department:"Computer Applications"},
                        {rollno:"3",name:"anu",batch:"MCA",department:"MComputer Applications"}];

  selstudent:any;                       
addstudent(data:any){
this.selstudent=data;
                        }                       
  constructor() { }

  ngOnInit() {
  }

}
