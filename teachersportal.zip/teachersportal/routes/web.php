<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@index');
Route::get('/apply', 'PagesController@apply');
Route::get('/Login', 'PagesController@Login');
Route::get('/about', 'PagesController@about');
Route::any('/Loginme','LoginController@Userlogin');
Route::any('/logout','LoginController@logout');
//Route::any('/Loginme','LoginController@Userlogin');
//Route::resource('Login', 'LoginController');
Route::resource('Register', 'RegisterController');
Route::get('/allteachersaa', 'AdminController@allteachers');
Route::get('/adminindex','AdminController@adminindex');
Route::get('/allteachers', 'RegisterController@index');//to display teachers
Route::get('/students', 'RegisterController@sindex');//to display students as table
Route::get('/studentss', 'AdminController@students');//to display studentspage in admin
Route::any('/Updateteachers/{id}','RegisterController@Updateteachers');//to block teachers
Route::any('/Updatestudents/{id}','RegisterController@Updatestudents');//to block students
Route::get('/teachersindex','TeachersController@teachersindex');//teachers index page
Route::get('/teachprofile','TeachersController@teachprofile');//teachers profile page
Route::resource('teachprofile', 'TeahersController');

Route::get('/teachprofile','TeachersController@index');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// $router->get('/updateteachers/{loginid}',[
//     'uses' => 'RegisterController@Updateteachers',
//     'as'   => 'update'
// ]);
