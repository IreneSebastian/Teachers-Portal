<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class School extends Model
{

    // public function district()
    // {
    //     return $this->belongsTo('districts');
    // }
    // public function login()
    // {
    //     return $this->belongsTo('logins');
    // }
    // public function register()

    //     {
    //         return $this->hasMany('App\Register', 'schoolid', 'schoolid');
    //     }
}
