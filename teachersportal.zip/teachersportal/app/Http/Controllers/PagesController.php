<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index()
	{
	return view('Pages.index');
	}
	public function apply()
	{
	return view('Pages.apply');
	}
	
	public function Login()
	{
	return view('Pages.Login');
	}
	
	public function about()
	{
	return view('Pages.about');
	}
	
}
