<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
    public $fillable=['fname',
    'lname',
    'uname',
    'utype',
    'ustatus'];
    // public function school()

    //     {
    //         return $this->belongsTo('App\school', 'schoolid', 'schoolid');
    //     }

}
