<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Login extends Model
{
    //protected $table="logins";
    //protected $primarykey="loginid";
    public $fillable=['rid',
    'uname',
    'password',
    'utype',
    'fname',
    'ustatus'];

    public $primaryKey = 'loginid';

    // public function school()
    // {
    //     return $this->hasMany('schools','loginid');
    // }
}
