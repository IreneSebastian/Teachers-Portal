function formvalidation()
{

    // Make quick references to our fields
    //var uname =  document.getElementById('uname');
    var fname =  document.getElementById('fname');
    var lname =  document.getElementById('lname');
    //var txt =  document.getElementById('txt');
   // var ph =  document.getElementById('ph');
    var uname =  document.getElementById('uname');
	var password=document.getElementById('password');
    var cpassword =  document.getElementById('cpassword');



    //  to check empty form fields.



    if(inputAlphabetf(fname)){

        if(lengthDefinef(fname, 3, 12)){

            if(inputAlphabetl(lname)){

                if(lengthDefinel(lname, 3, 12)){

                    if(emailValidation(uname)){


							//if(phoneValidation(ph)){

                            if(validatePass(password.value)){

                                if(validatePassword(password.value, cpassword.value)){

                                    if(fname.value.length == 0 || lname.value.length == 0 || password.value.length == 0 ||uname.value.length==0 ||cpassword.value.length == 0 )
    {
        $("#head").show().delay(1000).fadeOut();
        document.getElementById('head').innerText = "All fields are mandatory"; //this segment displays the validation rule for all fields
        fname.focus();
        return false;
    }

                                    return true;
                                }
                            }
                        }
                    }
                }
            }


     return false;
}



//function that checks whether input text is an alphabetic character or not.

function inputAlphabetf(inputtext){
    var alphaExp = /^[a-zA-Z]+$/;
    if(inputtext.value.match(alphaExp)){
        document.getElementById('p1').innerText = "";

        return true;
    }else{
        // document.getElementById('p1').innerText = "Enter valid name";  //this segment displays the validation rule for name
        $("#p1").html("Enter valid name").fadeIn().delay('1000').fadeOut();
        fname.value = '';
        return false;
    }
}
function inputAlphabett(inputtext){
    var alphaExp = /^[a-zA-Z]+$/;
    if(inputtext.value.match(alphaExp)){
        document.getElementById('p8').innerText = "";

        return true;
    }else{
        // document.getElementById('p1').innerText = "Enter valid name";  //this segment displays the validation rule for name
        $("#p8").html("Enter valid name").fadeIn().delay('1000').fadeOut();
        fname.value = '';
        return false;
    }
}

// function inputAlphabetu(inputtext){
//     var alphaExp = /^[a-zA-Z0-9]+$/;
//     if(inputtext.value.match(alphaExp)){
//         document.getElementById('p4').innerText = "";
//         return true;
//     }else{
//         document.getElementById('p4').innerText = "Enter valid Username";  //this segment displays the validation rule for name
//         $("#p4").html("<p>Enter valid Username</p>").fadeIn().delay('1000').fadeOut();
//         uname.value = '';
//         return false;
//     }
// }

function inputAlphabetl(inputtext){
   var alphaExp = /^[a-zA-Z]+$/;
   if(inputtext.value.match(alphaExp)){
       document.getElementById('p2').innerText = "";

       return true;
   }else{
       // document.getElementById('p2').innerText = "Enter valid name";  //this segment displays the validation rule for name
       $("#p2").html("<p>Enter valid name</p>").fadeIn().delay('1000').fadeOut();
       lname.value = '';
       return false;
   }
}


// Function that checks whether the input characters are restricted according to defined by user.

function lengthDefineu(inputtext, min, max){
    var uInput = inputtext.value;
    if(uInput.length >= min && uInput.length <= max){
        document.getElementById('p4').innerText = "";

        return true;
    }else{

        // document.getElementById('p4').innerText = "Enter name between " +min+ " and " +max+ " characters *"; //this segment displays the validation rule for username
        $("#p4").html("<p>Enter name between " +min+ " and " +max+ " characters</p>").fadeIn().delay('1000').fadeOut();
        inputtext.value = '';
        return false;
    }
}


 function phoneValidation(inputtext){
     var uInput = inputtext.value;
     var regex=  /(6|7|8|9)\d{9}/;
     if(uInput.length == 10) {
         document.getElementById('p4').innerText = "";
         return true;
     }
         else if(isNaN(inputtext.value)){
             $("#p4").html("<p>Enter valid Mobile Number</p>").fadeIn().delay('1000').fadeOut();
             inputtext.value = '';
             return false;
         }
         else if(inputtext.value.match(regex)){
             document.getElementById('p4').innerText = "";
         return true;
         }
         else{
             $("#p4").html("<p>Enter valid Mobile Number</p>").fadeIn().delay('1000').fadeOut();
             ph.value = '';
             return false;
         }
 }


function lengthDefinel(inputtext, min, max){
    var uInput = inputtext.value;
    if(uInput.length >= min && uInput.length <= max){
        document.getElementById('p2').innerText = "";

        return true;
    }else{

        // document.getElementById('p2').innerText = "Enter name between " +min+ " and " +max+ " characters *"; //this segment displays the validation rule for username
        $("#p2").html("<p>Enter name between " +min+ " and " +max+ " characters</p>").fadeIn().delay('1000').fadeOut();
        inputtext.value = '';
        return false;
    }
}

function lengthDefinef(inputtext, min, max){
    var uInput = inputtext.value;
    if(uInput.length >= min && uInput.length <= max){
        document.getElementById('p1').innerText = "";

        return true;
    }else{

        // document.getElementById('p1').innerText = "Enter name between " +min+ " and " +max+ " characters *"; //this segment displays the validation rule for username
        $("#p1").html("<p>Enter name between " +min+ " and " +max+ " characters</p>").fadeIn().delay('1000').fadeOut();
        inputtext.value = '';
        return false;
    }
}



// Function that checks whether an user entered valid email address or not and displays alert message on wrong email address format.

function emailValidation(inputtext){
    var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
    if(inputtext.value.match(emailExp)){
        document.getElementById('p3').innerText = "";
        return true;
    }else{
        // document.getElementById('p3').innerText = "Enter a vaild email"; //this segment displays the validation rule for email
        $("#p3").html("Enter a vaild email").fadeIn().delay('1000').fadeOut();
        uname.value = '';
        return false;
     }
}

       // function validatePassword(pass,cpass){
            //if(password == cpassword) {
            //document.getElementById('p6').innerText = ""; return true; } else {
                // document.getElementById('p5').innerText = "Check your password";
             //   $("#p6").html("<p>Password Miss match</p>").fadeIn().delay('1000').fadeOut();
           //     document.getElementById('cpswd').value = ''; return false;
         //   }
       // }
        function validatePass(password){
            if(password.length>5) {
            document.getElementById('p5').innerText = "";
            return true; }
             else {
                // document.getElementById('p5').innerText = "Check your password";
                $("#p5").html("<p>Password must contain Atleast 6 Characters</p>").fadeIn().delay('1000').fadeOut();
                document.getElementById('password').value = ''; return false;
            }
        }
        function validatePassword(password,cpassword){
            if(password == cpassword) {
            document.getElementById('p6').innerText = ""; return true; } else {
                // document.getElementById('p5').innerText = "Check your password";
                $("#p6").html("<p>Password Miss match</p>").fadeIn().delay('1000').fadeOut();
                document.getElementById('cpassword').value = ''; return false;
            }
        }


//              function emailDoesExist(){
//                  var email = $("#email").val();
//                  $('#submit1').addClass('disabled');
//                  if(email != ''){
//                      $.ajax({
//                          url: 'check.php',
//                          type: 'post',
//                          data: {'email':email},
//                          success: function(response){
//                              // console.log(response);
//                              if(response > 0){
//                                  $("#email").val('');
//                                  $('#submit1').removeClass('disabled');
//                                  $("#eval").html("<p>Email Already taken</p>").fadeIn().delay('1000').fadeOut();
//                              }

//                          }
//                      });

//                  }else{
//                      $("#eval").hide();
//                  }
//              }

//              function usernameDoesExist(){
//                  var uname = $("#uname").val();
//                  $('#submit1').addClass('disabled');
//                  if(uname != ''){
//                      $.ajax({
//                          url: 'check.php',
//                          type: 'post',
//                          data: {'uname':uname},
//                          success: function(response){

//                              if(response > 0){
//                                  $("#uname").val('');
//                                  $("#uval").html("<p>Username Already taken</p>").fadeIn().delay('1000').fadeOut();
//                              }

//                          }
//                      });
//                  }else{
//                      $("#uval").hide();
//                      $('#submit1').removeClass('disabled');

//                  }
//              }

                // $(document).ready(function(){
                //  $(".validate").on('blur', function(){
                //      $type = $(this).data("type");

                //      switch($type)
                //      {
                //          case 'email':
                //          if(emailValidation(this))
                //          {
                //              emailDoesExist();
                //          }
                //          break;
//                          case 'fname':
//                          if(lengthDefinef(this,3,12))
//                          {
//                              inputAlphabetf(this);
//                          }
//                          break;
//                          case 'lname':
//                          if(lengthDefinel(this,3,12))
//                          {
//                              inputAlphabetl(this);
//                          }
//                          break;
//                          case 'uname':
//                          if(inputAlphabetu(this))
//                          {
//                              if(lengthDefineu(this,6,12)){
//                                  usernameDoesExist();
//                              }

//                          }
//                          break;
//                          case 'cpass':
//                          validatePassword($("#pass").val(),$("#cpass").val());
//                          break;
                //      }

                //  })

                // });
    }
