﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Connectivity.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }

        [Required(ErrorMessage="*needed")]
        [Display(Name="Name")]
        [DataType(DataType.Text)]
        public string cname { get; set; }

        [Required(ErrorMessage = "*needed")]
        [Display(Name = "Address")]
        [DataType(DataType.MultilineText)]
        public string caddress { get; set; }

        [Required(ErrorMessage = "*needed")]
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress)]
        public string cemail { get; set; }

        [Required(ErrorMessage = "*needed")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string cpassword{get;set;}
    }
}