<form method="post" action="<?php echo e(route('student.store')); ?>">
<?php echo csrf_field(); ?>
Name: <input type="text" name="name"/><br/>
RollNo:<input type="text" name="rollno"/><br/>
Batch:<input type="text" name="batch"/><br/>
<button type="submit">Add</button>
</form>
