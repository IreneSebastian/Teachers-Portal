<form method="post" action="<?php echo e(route('student.update',$students->id)); ?>">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
name<input  type="text" name="name" value="<?php echo e($students->name); ?>"/>
rollno<input  type="text" name="rollno" value="<?php echo e($students->rollno); ?>"/>
batch<input  type="text" name="batch" value="<?php echo e($students->batch); ?>"/>
<button type="submit">Update</button>
</form>
	