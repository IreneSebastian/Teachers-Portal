<?php $__env->startSection('content'); ?>
<h1>about page</h1>
<h2>MCA department</h2>
<h3><?php echo e($value); ?></h3>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>