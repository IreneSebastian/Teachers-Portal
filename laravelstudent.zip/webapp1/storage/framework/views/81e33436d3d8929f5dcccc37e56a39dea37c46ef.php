<form method="post" action="<?php echo e(route('books.update',$books->id)); ?>">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
title<input  type="text" name="title" value="<?php echo e($books->title); ?>"/>
body<input  type="text" name="body" value="<?php echo e($books->body); ?>"/>
<button type="submit">Update</button>
</form>
	