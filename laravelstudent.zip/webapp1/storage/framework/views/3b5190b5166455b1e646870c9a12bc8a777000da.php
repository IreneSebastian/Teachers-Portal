<table border="1">
	<thead>
		<tr>
		<td>Name</td>
		<td>Rollno</td>
		<td>Batch</td>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($student->name); ?></td>
		<td><?php echo e($student->rollno); ?></td>
		<td><?php echo e($student->batch); ?></td>
		<td>
		<a href="<?php echo e(route('student.edit',$student->id)); ?>">EDIT</a>
		</td>
		<td>
		<form action="<?php echo e(route('student.destroy',$student->id)); ?>" method="post">
		<?php echo csrf_field(); ?>
		<?php echo method_field('DELETE'); ?>
		<button type="submit">DELETE</button>
		</form>
		</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>