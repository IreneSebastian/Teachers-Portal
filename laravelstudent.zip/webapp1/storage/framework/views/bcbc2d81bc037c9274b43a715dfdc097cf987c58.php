<form method="post" action="<?php echo e(route('bottle.store')); ?>">
<?php echo csrf_field(); ?>
Name: <input type="text" name="title"/><br/>
Company:<input type="text" name="company"/><br/>
Brand:<input type="text" name="brand" /><br/>
<button type="submit" name="submit">Add</button>
</form>