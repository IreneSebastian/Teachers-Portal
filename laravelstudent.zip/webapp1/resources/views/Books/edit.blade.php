<form method="post" action="{{route('books.update',$books->id)}}">
@method('PATCH')
@csrf
title<input  type="text" name="title" value="{{$books->title}}"/>
body<input  type="text" name="body" value="{{$books->body}}"/>
<button type="submit">Update</button>
</form>
	