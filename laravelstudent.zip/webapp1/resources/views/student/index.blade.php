<table border="1">
	<thead>
		<tr>
		<td>Name</td>
		<td>Rollno</td>
		<td>Batch</td>
		</tr>
	</thead>
	<tbody>
	@foreach($students as $student)
	<tr>
		<td>{{$student->name}}</td>
		<td>{{$student->rollno}}</td>
		<td>{{$student->batch}}</td>
		<td>
		<a href="{{route('student.edit',$student->id)}}">EDIT</a>
		</td>
		<td>
		<form action="{{route('student.destroy',$student->id)}}" method="post">
		@csrf
		@method('DELETE')
		<button type="submit">DELETE</button>
		</form>
		</td>
		</tr>
	@endforeach
	</tbody>
</table>