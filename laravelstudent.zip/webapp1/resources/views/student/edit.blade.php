<form method="post" action="{{route('student.update',$students->id)}}">
@method('PATCH')
@csrf
name<input  type="text" name="name" value="{{$students->name}}"/>
rollno<input  type="text" name="rollno" value="{{$students->rollno}}"/>
batch<input  type="text" name="batch" value="{{$students->batch}}"/>
<button type="submit">Update</button>
</form>
	