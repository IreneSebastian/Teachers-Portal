<form method="post" action="{{route('student.store')}}">
@csrf
Name: <input type="text" name="name"/><br/>
RollNo:<input type="text" name="rollno"/><br/>
Batch:<input type="text" name="batch"/><br/>
<button type="submit">Add</button>
</form>
