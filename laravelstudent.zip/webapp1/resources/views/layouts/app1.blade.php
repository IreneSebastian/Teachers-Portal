<html>
<body>
<div>
<a href="/index">Home</a>
<a href="/about">About</a>
<a href="/services">Services</a>
</div>
@yield('content')
</body>
</html>
