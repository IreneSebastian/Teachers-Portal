@extends('layouts.app1')
@section('content')
<h1>about page</h1>
<h2>MCA department</h2>
<h3>{{$value}}</h3>
@endsection

