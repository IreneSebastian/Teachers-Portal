
@extends('layouts.app1')
@section('content')
<h1>Index Page</h1>
<h2>hi this is index page</h2>
<h3>{{$name}}</h3>
@endsection

