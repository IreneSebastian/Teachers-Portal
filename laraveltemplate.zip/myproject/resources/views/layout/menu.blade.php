<html>
<body>
<div>
<a href="register">Register</a>
<a href="login">Login</a>

</div>
@yield('content')
</body>
</html>